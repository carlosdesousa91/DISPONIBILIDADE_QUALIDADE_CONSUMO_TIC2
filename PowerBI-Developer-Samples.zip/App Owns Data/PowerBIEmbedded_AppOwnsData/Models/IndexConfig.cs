﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PowerBIEmbedded_AppOwnsData.Models
{
    public class IndexConfig
    {
        public string DotNETSDK { get; internal set; }
    }
}